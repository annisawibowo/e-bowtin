<?php $conn = mysqli_connect('localhost','id8592770_evoting','aremanita1012');
mysqli_select_db($conn, 'id8592770_evoting');
?>