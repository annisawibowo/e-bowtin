<?php 
include 'koneksi.php';
$nomk = $_POST['NOMK'];
$nip= $_POST['NIP'];

    $sql = "insert into mengajar values ('".$nomk."','".$nip."')";
    mysqli_query($conn, $sql);
   
    
header("location:absensi.php");

	

?>