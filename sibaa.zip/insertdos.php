<?php 
include 'koneksi.php';
$nip = $_POST['NIP'];
$nama= $_POST['NAMA'];
$alamat = $_POST['ALAMAT'];


    $sql = "insert into dosen values ('".$nip."','".$nama."','".$alamat."')";
    mysqli_query($conn, $sql);
   
    
header("location:dosen.php");

	

?>