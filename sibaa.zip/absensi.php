<html lang="en">
<?php include 'koneksi.php'; ?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
  <?php include 'css.html'; ?>
    <style>
body {
  
}
.container-md {
  background-color: white;
}
</style>
</head>
<body >
<div class="container-fluid">
<?php include 'navbar.html'; ?>
<div class="row">
  <div class="col-3">
    <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
      <a class="nav-link " id="v-pills-home-tab"  href="index.php" role="tab" aria-controls="v-pills-home" aria-selected="false">Home</a>
      <a class="nav-link"   id="v-pills-messages-tab" href="daftarMK.php"  aria-controls="v-pills-profile" role="tab" aria-selected="false">Daftar Mata Kuliah</a>
      <a class="nav-link" id="v-pills-messages-tab"  href="dosen.php" role="tab" aria-controls="v-pills-messages" aria-selected="false">Daftar Dosen</a>
      <a class="nav-link" id="v-pills-settings-tab" href="mahasiswa.php" role="tab" aria-controls="v-pills-settings" aria-selected="false">Daftar Mahasiswa</a>
      <a class="nav-link active" id="v-pills-settings-tab"  href="absensi.php" role="tab" aria-controls="v-pills-settings" aria-selected="true">Absensi</a>    
    </div>
  </div>
  <div class="col-9">
    <div class="tab-content" id="v-pills-tabContent">
     

      <div class="tab-pane fade show active" id="v-pills-setting" role="tabpanel" aria-labelledby="v-pills-setting-tab">
   <h4 class="text-primary"> RELASI MATAKULIAH DENGAN DOSEN PENGAJAR </h4>
    <table class="table">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">MATA KULIAH </th>
      <th scope="col">DOSEN </th>
      <th scope="col">INPUT</th>
      <?php 
$qe = "SELECT * FROM matakuliah ";
$quer = mysqli_query($conn,$qe);
$resul = mysqli_fetch_row($quer); 
$qer = "SELECT * FROM dosen ";
$que = mysqli_query($conn,$qer);
$resu = mysqli_fetch_row($que); 
?>
    </tr>
  </thead>
  <tbody>
  <?php
  $no=1; do { do {?>
  <form method='post' action='insertngajar.php'>
    <tr>
      <th scope="row"><?php echo $no ?></th>
      <td><select name='NOMK'>
      <option value="<?php echo $resul[0]; ?>"><?php echo $resul[0]; ?>-<?php echo $resul[1]; ?></option>  </select>    
      </td>
      <td><select name='NIP'>
      <option value="<?php echo $resu[0]; ?>"><?php echo $resu[0]; ?>-<?php echo $resu[1]; ?></option>  </select></td>
      <td> <button type="submit" class="btn btn-primary">Simpan</button></td>
      
    </tr>
 
    <?php 
      
      $resu = mysqli_fetch_row($que);
    }while($resu); 
    $resul = mysqli_fetch_row($quer);
}while($resul); ?>
    </form>
  </tbody>
</table>
<h4 class="text-primary"> RELASI MATAKULIAH DENGAN MAHASISWA </h4>
    <table class="table">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">MATA KULIAH </th>
      <th scope="col">DOSEN </th>
      <th scope="col">INPUT</th>
      </div>
      <?php
      $qer = "SELECT * FROM matakuliah ";
      $mk = mysqli_query($conn,$qer);
      $mkrel = mysqli_fetch_row($mk); 
      $qr = "SELECT * FROM mahasiswa ";
      $qu = mysqli_query($conn,$qr);
      $re = mysqli_fetch_row($qu);
  $no=1; do { do {?>
  <form method='post' action='insertngikut.php'>
    <tr>
      <th scope="row"><?php echo $no ?></th>
      <td><select name='NOMK'>
      <option value="<?php echo $mkrel[0]; ?>"><?php echo $mkrel[0]; ?>-<?php echo $mkrel[1]; ?></option>  </select>    
      </td>
      <td><select name='NPM'>
      <option value="<?php echo $re[0]; ?>"><?php echo $re[0]; ?>-<?php echo $re[1]; ?></option>  </select></td>
      <td> <button type="submit" class="btn btn-primary">Simpan</button></td>
      
    </tr>
 
    <?php 
      
      $mkrel = mysqli_fetch_row($mk);
    }while($mkrel); 
    $re = mysqli_fetch_row($qu);
}while($re); ?>
    </form>
  </tbody>
</table>
</div>

</body>
</html>