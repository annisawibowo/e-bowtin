<?php 
include 'koneksi.php';
$nomk = $_POST['NOMK'];
$npm= $_POST['NPM'];

    $sql = "insert into mengikuti values ('".$npm."','".$nomk."')";
    mysqli_query($conn, $sql);
   
    
header("location:absensi.php");

	

?>