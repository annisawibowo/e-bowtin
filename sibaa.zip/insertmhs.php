<?php 
include 'koneksi.php';
$npm = $_POST['NPM'];
$nama= $_POST['NAMA'];
$alamat = $_POST['ALAMAT'];


    $sql = "insert into mahasiswa values ('".$npm."','".$nama."','".$alamat."')";
    mysqli_query($conn, $sql);
   
    
header("location:mahasiswa.php");

	

?>