<?php 
include 'koneksi.php';
$nomk = $_POST['NOMK'];
$namamk= $_POST['NAMAMK'];
$sks = $_POST['SKS'];
$jam= $_POST['JAM'];
$kelas = $_POST['KELAS'];

    $sql = "insert into matakuliah values ('".$nomk."','".$namamk."','".$sks."','".$jam."','".$kelas."')";
    mysqli_query($conn, $sql);
   
    
header("location:daftarMK.php");

	

?>