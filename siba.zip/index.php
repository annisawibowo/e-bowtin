<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
  <?php include 'css.html'; ?>
    <style>
body {
  
}
.container-md {
  background-color: white;
}
</style>
</head>
<body >
<div class="container-fluid">
<?php include 'navbar.html';
include 'koneksi.php';?>
<div class="row">
  <div class="col-3">
    <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
      <a class="nav-link active" id="v-pills-home-tab" href="index.php" role="tab" aria-controls="v-pills-home" aria-selected="true">Home</a>
      <a class="nav-link"   id="v-pills-messages-tab" href="daftarMK.php"  aria-controls="v-pills-profile" role="tab" aria-selected="false">Daftar Mata Kuliah</a>
      <a class="nav-link" id="v-pills-messages-tab"  href="dosen.php" role="tab" aria-controls="v-pills-messages" aria-selected="false">Daftar Dosen</a>
      <a class="nav-link" id="v-pills-settings-tab" href="mahasiswa.php" role="tab" aria-controls="v-pills-settings" aria-selected="false">Daftar Mahasiswa</a>
      <a class="nav-link" id="v-pills-settings-tab"  href="absensi.php" role="tab" aria-controls="v-pills-settings" aria-selected="false">Absensi</a>    
    </div>
  </div>
  <div class="col-9">
    <div class="tab-content" id="v-pills-tabContent">
      <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
          <h4> Cari Absensi </h4>
         <?php $qe = "SELECT * FROM matakuliah ";
$quer = mysqli_query($conn,$qe);
$resul = mysqli_fetch_row($quer); 
$qer = "SELECT * FROM dosen ";
$que = mysqli_query($conn,$qer);
$resu = mysqli_fetch_row($que); 
?>

<form method="post" action='#'>
<div class="input-group">
  <select class="custom-select" name='NOMK' id="inputGroupSelect04" aria-label="Example select with button addon">
      <option value="<?php echo $resul[0]; ?>"><?php echo $resul[0]; ?>-<?php echo $resul[1]; ?></option>  </select>
  <select class="custom-select" name='NIP' id="inputGroupSelect04" aria-label="Example select with button addon">
  
      <option value="<?php echo $resu[0]; ?>"><?php echo $resu[0]; ?>-<?php echo $resu[1]; ?></option>  </select>
     
  <div class="input-group-append">
    <button class="btn btn-outline-secondary" name='simpan' type="button-submit">Cari</button>
  </div>
</div>
</form>
<?php
if (isset($_POST['simpan'])){
    $matkul = $_POST['NOMK'];
    $nip= $_POST['NIP']; 
    $q = "SELECT a.npm,mk.kelas,a.waktu,a.ketabsen,m.nama FROM mahasiswa m join absensi a on (a.npm=m.npm) join matakuliah mk on(a.NOMK=mk.NOMK) where a.nomk='$matkul' and a.nip='$nip'";
    $query = mysqli_query($conn,$q);
    $result = mysqli_fetch_row($query); ?>
    
 <table class="table ">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">NPM </th>
      <th scope="col">Nama Mahasiswa</th>
      <th scope="col">Kelas</th>
      <th scope="col">Waktu</th>
      <th scope="col">Keterangan</th>
      
    </tr>
  </thead>
  <tbody>
  <?php
  $no=1; do {?>
    <tr>
      <th scope="row"><?php echo $no ?></th>
      <td><?php echo $result[0]?></td>
      <td><?php echo $result[4]?></td>
      <td><?php echo $result[1]?></td>
      <td><?php echo $result[2]?></td>
      <td><?php echo $result[3]; $no++;?></td>
    </tr>
   <?php $result = mysqli_fetch_row($query);
}while($result); ?>
    
    
  </tbody>
</table>
    
<?php
}
?>
 
</div>
          
      </div>
      

      <div class="tab-pane fade" id="v-pills-setting" role="tabpanel" aria-labelledby="v-pills-setting-tab">
      jhidb
      
      </div>
    
</div>

</body>
</html>