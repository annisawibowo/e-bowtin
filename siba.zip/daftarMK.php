<html lang="en">
<?php include 'koneksi.php'; ?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
  <?php include 'css.html'; ?>
    <style>
body {
  
}
.container-md {
  background-color: white;
}
</style>
</head>
<body >
<div class="container-fluid">
<?php include 'navbar.html'; ?>
<div class="row">
  <div class="col-3">
    <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
      <a class="nav-link" id="v-pills-home-tab" href="index.php" role="tab" aria-controls="v-pills-home" aria-selected="false">Home</a>
      <a class="nav-link active" id="v-pills-profile-tab"  href="daftarMK.php" role="tab" aria-controls="v-pills-profile" aria-selected="true">Daftar Mata Kuliah</a>
      <a class="nav-link" id="v-pills-messages-tab"  href="dosen.php" role="tab" aria-controls="v-pills-messages" aria-selected="false">Daftar Dosen</a>
      <a class="nav-link" id="v-pills-settings-tab" href="mahasiswa.php" role="tab" aria-controls="v-pills-settings" aria-selected="false">Daftar Mahasiswa</a>
      <a class="nav-link" id="v-pills-settings-tab" href="absensi.php" role="tab" aria-controls="v-pills-settings" aria-selected="false">Absensi</a>    
    </div>
  </div>
  <div class="col-9">
    <div class="tab-content" id="v-pills-tabContent">
      <div class="tab-pane fade show active" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
      <ul class="nav nav-tabs" role="tablist">
  <li class="nav-item">
    <a class="nav-link active" href="#profile" role="tab" data-toggle="tab">Daftar Mata Kuliah</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#buzz" role="tab" data-toggle="tab">Tambah Mata Kuliah</a>
  </li>
 
</ul>
<?php 
$q = "SELECT * FROM matakuliah ";
$query = mysqli_query($conn,$q);
$result = mysqli_fetch_row($query); ?>
<!-- Tab panes -->
<div class="tab-content">
  <div role="tabpanel" class="tab-pane fade show active" id="profile"> 
      <table class="table ">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Kode </th>
      <th scope="col">Nama </th>
      <th scope="col">SKS</th>
      <th scope="col">Jam</th>
      <th scope="col">Kelas</th>
    </tr>
  </thead>
  <tbody>
  <?php
  $no=1; do {?>
    <tr>
      <th scope="row"><?php echo $no ?></th>
      <td><?php echo $result[0]?></td>
      <td><?php echo $result[1]?></td>
      <td><?php echo $result[2]?></td>
      <td><?php echo $result[3]?></td>
      <td><?php echo $result[4]; $no++;?></td>
    </tr>
   <?php $result = mysqli_fetch_row($query);
}while($result); ?>
    
    
  </tbody>
</table></div>
  <div role="tabpanel" class="tab-pane fade" id="buzz">
  <form method='POST' action='insertmk.php' >
  <div class="form-group">
    <label for="exampleInputEmail1">Kode Mata Kuliah</label>
    <input type="text" class="form-control" name='NOMK'>
    <!--<small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>-->
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Nama Mata Kuliah</label>
    <input type="text" class="form-control" name='NAMAMK'>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">SKS</label>
    <input type="text" class="form-control" name='SKS'>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Jam</label>
    <input type="time" class="form-control" name='JAM'>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Kelas</label>
    <input type="text" class="form-control" Name='KELAS' >
  </div>
  <button type="submit" class="btn btn-primary">Simpan</button>
</form></div>
  
</div>
      </div>
<!-- kedua -->
  
</div>

</body>
</html>