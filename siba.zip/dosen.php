<html lang="en">
<?php include 'koneksi.php'; ?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
  <?php include 'css.html'; ?>
    <style>
body {
  
}
.container-md {
  background-color: white;
}
</style>
</head>
<body >
<div class="container-fluid">
<?php include 'navbar.html'; ?>
<div class="row">
  <div class="col-3">
    <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
      <a class="nav-link " id="v-pills-home-tab" href="index.php" role="tab" aria-controls="v-pills-home" aria-selected="false">Home</a>
      <a class="nav-link"   id="v-pills-messages-tab" href="daftarMK.php"  aria-controls="v-pills-profile" role="tab" aria-selected="false">Daftar Mata Kuliah</a>
      <a class="nav-link active" id="v-pills-messages-tab"  href="dosen.php" role="tab" aria-controls="v-pills-messages" aria-selected="true">Daftar Dosen</a>
      <a class="nav-link" id="v-pills-settings-tab" href="mahasiswa.php" role="tab" aria-controls="v-pills-settings" aria-selected="false">Daftar Mahasiswa</a>
      <a class="nav-link" id="v-pills-settings-tab"  href="absensi.php" role="tab" aria-controls="v-pills-settings" aria-selected="false">Absensi</a>    
    </div>
  </div>
  <div class="col-9">
    <div class="tab-content" id="v-pills-tabContent">
      
      
<!-- kedua -->
      <div class="tab-pane fade show active" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
      <ul class="nav nav-tabs" role="tablist">
  <li class="nav-item">
    <a class="nav-link active" href="#dosen" role="tab" data-toggle="tab">Daftar Dosen</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#tambahdos" role="tab" data-toggle="tab">Tambah Dosen</a>
  </li>
 
</ul>

<!-- Tab panes -->
<div class="tab-content">
  <div role="tabpanel" class="tab-pane fade show active" id="dosen"> <table class="table">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">NIP </th>
      <th scope="col">Nama </th>
      <th scope="col">Alamat</th>
    
    </tr>
    <?php 
$q = "SELECT * FROM dosen ";
$query = mysqli_query($conn,$q);
$result = mysqli_fetch_row($query); ?>
  </thead>
  <tbody>
  <?php $no=1; do{ ?>
    <tr>
      <th scope="row"><?php echo $no ?></th>
      <td><?php echo $result[0]?></td>
      <td><?php echo $result[1]?></td>
      <td><?php echo $result[2]?></td>
      
    </tr>
       <?php $result = mysqli_fetch_row($query);
}while($result); ?>
    
  </tbody>
</table></div>
  <div role="tabpanel" class="tab-pane fade" id="tambahdos">
  <form method='post' action='insertdos.php'>
  <div class="form-group">
    <label for="exampleInputEmail1">NIP</label>
    <input type="text" class="form-control" name='NIP'>
    <!--<small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>-->
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Nama Dosen</label>
    <input type="text" name='NAMA' class="form-control" >
    <small  class="form-text text-muted" >Nama Lengkap</small>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Alamat</label>
    <input type="text" class="form-control" name='ALAMAT' >
  </div>
 
  <button type="submit" class="btn btn-primary">Simpan</button>
</form></div>
  
</div>
      </div>
</div>

</body>
</html>