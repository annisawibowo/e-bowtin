
	
		<?php
include 'koneksi.php';
	//$db_conn = mysqli_connect('localhost', 'root', '');
	//mysqli_select_db($db_conn,'nfc');
	$npm = $_POST['npm'];
		$waktu = $_POST['waktu'];
		
	$sql = "insert into absensi (KODEABSEN,NOMK,npm,NIP,KETABSEN,waktu,SURAT) values (001,'A001','".$npm."','001','Masuk','".$waktu."','')";
	mysqli_query($conn, $sql);
	
?>